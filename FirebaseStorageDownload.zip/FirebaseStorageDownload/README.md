# FirebaseUploadImage
This project is for uploading images to google cloud storage using firebase. 

Note : Connect your android project to firebase console and add google-services.json file to 'app' folder of your project.       

Learn more about how to use all firebase services in android app development - 
https://www.udemy.com/course/android-app-firebase-authentication-realtime-database-fcm-crashlytics/?referralCode=5EA688DA64FF2471050A
